
package user;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import java.util.concurrent.ThreadFactory;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.util.Scanner;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import javax.swing.JOptionPane;

/**
 *
 * @author Admin
 */
public final class add extends javax.swing.JFrame implements Runnable, ThreadFactory {
    
    private WebcamPanel camPanel = null;
    private Webcam BcScan = null;
    private Executor ex = Executors.newSingleThreadExecutor(this);

    
    public add() {
        initComponents();
        initWebcam();
        Connect();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        Fetch();
        
        
    }

    Connection con;
    
    PreparedStatement pst;
    public void Connect(){
        
        
        try{
           con = DriverManager.getConnection("jdbc:mysql://localhost:3307/loginsystem","root","");
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        
    }
    
    
    private void Fetch(){
        try {
            int q;
            pst = con.prepareStatement("SELECT * FROM product_tbl1");
            ResultSet rs = pst.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            q = rss.getColumnCount();
            
            DefaultTableModel df = (DefaultTableModel)jTable1.getModel();
            df.setRowCount(0);
            while(rs.next()){
                Vector v2 = new Vector();
                
                for(int a=1; a<=q; a++){
                    v2.add(rs.getString("ProductId"));
                    v2.add(rs.getString("ProductName"));
                    v2.add(rs.getString("Barcode"));
                    v2.add(rs.getString("Price"));
                
                
            }
            df.addRow(v2);
            }
                        
        } catch (SQLException ex) {
            Logger.getLogger(add.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    } 
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelBorder1 = new com.raven.swing.PanelBorder();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtProductname = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtbarcode = new javax.swing.JTextField();
        btnAddnew = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btbSave = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        txtPrice = new javax.swing.JTextField();
        txtProductid = new javax.swing.JTextField();
        Scanner = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelBorder1.setBackground(new java.awt.Color(255, 255, 255));
        panelBorder1.setMaximumSize(new java.awt.Dimension(1650, 1080));
        panelBorder1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Product Id", "Product Name", "Barcode", "Price"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        panelBorder1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 270, 920, 510));

        jLabel8.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18)); // NOI18N
        jLabel8.setText("Product Id:");
        jLabel8.setEnabled(false);
        panelBorder1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 30, 112, 43));

        jLabel9.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18)); // NOI18N
        jLabel9.setText("Product Name:");
        panelBorder1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 90, 149, 43));
        panelBorder1.add(txtProductname, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 90, 145, 43));

        jLabel10.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18)); // NOI18N
        jLabel10.setText("Barcode:");
        panelBorder1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 140, -1, 43));

        txtbarcode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbarcodeActionPerformed(evt);
            }
        });
        panelBorder1.add(txtbarcode, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 150, 145, 43));

        btnAddnew.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnAddnew.setText("ADD NEW");
        btnAddnew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddnewActionPerformed(evt);
            }
        });
        panelBorder1.add(btnAddnew, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 30, 153, 50));

        btnUpdate.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnUpdate.setText("UPDATE");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        panelBorder1.add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 110, 155, 50));

        btnClear.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnClear.setText("CLEAR");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });
        panelBorder1.add(btnClear, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 190, 160, 50));

        btnDelete.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnDelete.setText("DELETE");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        panelBorder1.add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 190, 160, 50));

        btbSave.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btbSave.setText("SAVE");
        btbSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbSaveActionPerformed(evt);
            }
        });
        panelBorder1.add(btbSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 110, 160, 50));

        jLabel12.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18)); // NOI18N
        jLabel12.setText("Price:");
        panelBorder1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 200, -1, 43));

        txtPrice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPriceActionPerformed(evt);
            }
        });
        panelBorder1.add(txtPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 200, 145, 43));

        txtProductid.setEnabled(false);
        txtProductid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProductidActionPerformed(evt);
            }
        });
        panelBorder1.add(txtProductid, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 30, 145, 52));

        Scanner.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelBorder1.add(Scanner, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, 270));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBorder1, javax.swing.GroupLayout.DEFAULT_SIZE, 1549, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelBorder1, javax.swing.GroupLayout.PREFERRED_SIZE, 835, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPriceActionPerformed

    private void btbSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbSaveActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(this, "All changes has been save!!!");
    }//GEN-LAST:event_btbSaveActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        
            try {
                pst = con.prepareStatement("DELETE FROM `product_tbl1` WHERE ProductId=?");
                
                pst.setString(1, txtProductid.getText());
                pst.executeUpdate();
                
                Fetch();
          JOptionPane.showMessageDialog(this, "Deleted Successfully..");
            } catch (SQLException ex) {
                Logger.getLogger(add.class.getName()).log(Level.SEVERE, null, ex);
            }
          
          

    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        // TODO add your handling code here:
        txtProductid.setText(null);
        txtProductname.setText(null);
        txtbarcode.setText(null);
        txtPrice.setText(null);
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
       try{
          pst = con.prepareStatement("UPDATE `product_tbl1` SET `ProductName`=?,`Barcode`=?,`Price`=? WHERE ProductId=?;");
          pst.setString(1, txtProductname.getText());
          pst.setString(2, txtbarcode.getText());
          pst.setString(3, txtPrice.getText());
          pst.setString(4, txtProductid.getText());
          pst.executeUpdate();
          Fetch();
          JOptionPane.showMessageDialog(this, "Update Successfully..");
          
       } catch (SQLException ex) {
            Logger.getLogger(add.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnAddnewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddnewActionPerformed
        try {
            String pname = txtProductname.getText();
            String bar = txtbarcode.getText();
            String price = txtPrice.getText();

            pst = con.prepareStatement("INSERT INTO product_tbl1(ProductName,Barcode,Price)VALUES(?,?,?)");
            pst.setString(1, pname);
            pst.setString(2, bar);
            pst.setString(3, price);

            int k = pst.executeUpdate();

            if (k==1){
                JOptionPane.showMessageDialog(this, "Record Added!! successfully!");
                txtProductname.setText("");
                txtbarcode.setText("");
                txtPrice.setText("");
                
                Fetch();

            }else{
                JOptionPane.showMessageDialog(this, "Record failed to save!!!");

            }
        } catch (SQLException ex) {
            Logger.getLogger(add.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnAddnewActionPerformed

    private void txtbarcodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbarcodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtbarcodeActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        DefaultTableModel tblModel = (DefaultTableModel) jTable1.getModel();
        
        String tblProductId = tblModel.getValueAt(jTable1.getSelectedRow(), 0).toString();
        String tblProductName = tblModel.getValueAt(jTable1.getSelectedRow(), 1).toString();
        String tblBarcode = tblModel.getValueAt(jTable1.getSelectedRow(), 2).toString();
        String tblPrice = tblModel.getValueAt(jTable1.getSelectedRow(), 3).toString();
       
        txtProductid.setText(tblProductId);
        txtProductname.setText(tblProductName);
        txtbarcode.setText(tblBarcode);
        txtPrice.setText(tblPrice);
    }//GEN-LAST:event_jTable1MouseClicked

    private void txtProductidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtProductidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtProductidActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(add.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(add.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(add.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(add.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new add().setVisible(true);
            }
        });
    }
    
    private void initWebcam(){
        Dimension size = WebcamResolution.QVGA.getSize();
        BcScan = Webcam.getWebcams().get(0);
        BcScan.setViewSize(size);
        camPanel = new WebcamPanel(BcScan);
        camPanel.setMirrored(true);
        camPanel.setPreferredSize(size);
        camPanel.setFPSDisplayed(true);
        Scanner.add (camPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, 270));
        ex.execute(this);
        
        
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Scanner;
    private javax.swing.JButton btbSave;
    private javax.swing.JButton btnAddnew;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private com.raven.swing.PanelBorder panelBorder1;
    private javax.swing.JTextField txtPrice;
    private javax.swing.JTextField txtProductid;
    private javax.swing.JTextField txtProductname;
    private javax.swing.JTextField txtbarcode;
    // End of variables declaration//GEN-END:variables

    @Override
    public void run() {
    do {
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
            ex.getMessage();
            }
            Result res = null;
            BufferedImage img = null;
            
            
            if(BcScan.isOpen()){
                if((img=BcScan.getImage())==null){
                    continue;
                }
            }
            
            LuminanceSource src = new BufferedImageLuminanceSource(img);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(src));
            try {
                res = new MultiFormatReader().decode(bitmap);
            } catch (NotFoundException ex) {
            }
            if (res!=null){
                txtbarcode.setText(res.getText());
            }

        } while (true);
    }

    @Override
    public Thread newThread(Runnable r) {
       Thread tr = new Thread(r, "My Thread");
        tr.setDaemon(true);
        return tr;
    }

    private void Scan() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private boolean shouldCloseWebcam() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}

